PROJET : ARCHITECTURE RÉSEAU D'ENTREPRISE

1. PRÉSENTATION

Ce projet consiste à concevoir et configurer une architecture réseau d'entreprise avec Cisco Packet Tracer.

2. FICHIERS DU PROJET

- Architecture_Reseau_Entreprise_Groupe1.pkt : fichier contenant la simulation du réseau.
- Documentation.pdf & Documentation.docx  : rapport de présentation du projet.
- Readme.txt : guide d'utilisation du projet.

3. GUIDE D'UTILISATION

1. Ouvrir Cisco Packet Tracer.
2. Ouvrir le fichier Architecture_Reseau.pkt.
3. Attendre que les équipements soient opérationnels.
4. Cliquer sur un ordinateur pour accéder à son terminal ou à son navigateur Web.
5. Tester la communication entre les équipements avec la commande ping.
6. Utiliser le navigateur pour accéder aux sites Web configurés.

4. SERVICES DISPONIBLES

- DHCP : attribution automatique des adresses IP.
- DNS : résolution des noms de domaine.
- Web : accès aux sites public et intranet.
- FTP : transfert de fichiers.
- Messagerie : envoi et réception de courriels.
- SSH : administration à distance des équipements.
- Sécurité : VLAN, Port Security et ACL.

5. NFORMATIONIS IMPORTANTES

Le réseau extérieur est représenté par un PC de test dans la simulation. Les services sont simulés dans Cisco Packet Tracer.

Bonne utilisation !